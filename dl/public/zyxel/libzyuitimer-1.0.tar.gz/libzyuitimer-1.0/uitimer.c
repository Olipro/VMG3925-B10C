/**
 *  @brief		user interface of timer.
 *  @details	user interface of timer.
 *  @author
	- unknown(porting from ZyNOS)
 *  @copyright
.


 *  Copyright (C) 2013 ZyXEL Communications, Corp.
 *  All Rights Reserved.
 *
 *  ZyXEL Confidential;
 *  Protected as an unpublished work, treated as confidential,
 *  and hold in trust and in strict confidence by receiving party.
 *  Only the employees who need to know such ZyXEL confidential information
 *  to carry out the purpose granted under NDA are allowed to access.
 *
 *  The computer program listings, specifications and documentation
 *  herein are the property of ZyXEL Communications, Corp. and shall
 *  not be reproduced, copied, disclosed, or used in whole or in part
 *  for any reason without the prior express written permission of
 *  ZyXEL Communications, Corp.
 *  @file				uitimer.c
 */

#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/select.h>
#include <sys/time.h>
#include <signal.h>
#include "timer_list.h"
#include "uitimer.h"

#include "zos_api.h"
#include "zlog_api.h"

#define UPTIME_FILE "/proc/uptime"

#ifndef BOOL
typedef unsigned char BOOL;
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

void *UITimerProc(void *arg);
void* freeTime( void* pData );

pthread_t timer_thread = 0;
pthread_mutex_t timerMutex;
pthread_mutex_t saveConfigTimerMutex;
struct timer_list time_list;
struct timer_list periodic_time_list;
BOOL timer_thread_running = FALSE;


void UITimer_Init(void){
	if(!timer_thread_running){
		timer_list_init(&time_list);
		timer_list_init(&periodic_time_list);
		pthread_mutex_init(&timerMutex, NULL);
		pthread_mutex_init(&saveConfigTimerMutex, NULL);
		timer_thread_running = TRUE;
		pthread_create(&timer_thread, NULL, UITimerProc, 0);
	}
	return;
}

void UITimer_Destory(void){
	if(timer_thread_running){
		UIDelAllTimer();
		timer_thread_running = FALSE;
		pthread_mutex_unlock(&timerMutex);
		pthread_kill(timer_thread, 0);
		pthread_join(timer_thread, NULL);
		timer_thread = 0;
	}
	return;
}

void *UITimerProc(void *arg)
{
	struct timeval_t        timer_val;
	CMTimer_t               *uitimer=NULL;
	timer_list_iterator_t   iter;

	ZLOG_INFO("thread starts");

	while (timer_thread_running)
	{
		//gettimeofday(&timer_val, NULL);
		getSystemUptime(&timer_val);
		memset(&iter,0,sizeof(timer_list_iterator_t));
		pthread_mutex_lock(&timerMutex);
		uitimer =(CMTimer_t*) timer_list_get_first( &time_list, &iter );
		pthread_mutex_unlock(&timerMutex);
		while(uitimer && timer_thread_running){
			if( 	(uitimer->timeout.tv_sec>timer_val.tv_sec) ||
			((uitimer->timeout.tv_sec == timer_val.tv_sec) &&(uitimer->timeout.tv_usec > timer_val.tv_usec))){
				pthread_mutex_lock(&timerMutex);
				uitimer =(CMTimer_t*) timer_list_get_next( &iter );
				pthread_mutex_unlock(&timerMutex);
				continue;
			}
			pthread_mutex_lock(&timerMutex);
			timer_list_iterator_remove(&iter);
			pthread_mutex_unlock(&timerMutex);
			if(uitimer->fn) {
				uitimer->fn();
			}
			ZOS_FREE(uitimer);
			uitimer =NULL;
			memset(&iter,0,sizeof(timer_list_iterator_t));
			pthread_mutex_lock(&timerMutex);
			uitimer =(CMTimer_t*) timer_list_get_first( &time_list, &iter );
			pthread_mutex_unlock(&timerMutex);
		}

		memset(&iter,0,sizeof(timer_list_iterator_t));
		pthread_mutex_lock(&timerMutex);
		uitimer =(CMTimer_t*) timer_list_get_first( &periodic_time_list, &iter );
		pthread_mutex_unlock(&timerMutex);
		while(uitimer && timer_thread_running){
			if( 	(uitimer->timeout.tv_sec>timer_val.tv_sec) ||
			((uitimer->timeout.tv_sec == timer_val.tv_sec) &&(uitimer->timeout.tv_usec > timer_val.tv_usec))){
				pthread_mutex_lock(&timerMutex);
				uitimer =(CMTimer_t*) timer_list_get_next( &iter );
				pthread_mutex_unlock(&timerMutex);
				continue;
			}
			if(uitimer->fn) {
				uitimer->fn();
			}
			memset(&(uitimer->timeout), 0, sizeof(struct timeval));
			memcpy(&(uitimer->timeout), &timer_val, sizeof(struct timeval));
			uitimer->timeout.tv_sec  +=  uitimer->TimerLen/1000;
			uitimer->timeout.tv_usec  +=  (uitimer->TimerLen%1000)*1000;
			pthread_mutex_lock(&timerMutex);
			uitimer =(CMTimer_t*) timer_list_get_next( &iter );
			pthread_mutex_unlock(&timerMutex);
		}

		timer_val.tv_sec = 1;
		timer_val.tv_usec = 0;
		select(0, NULL, NULL, NULL, (struct timeval *)&timer_val);
	}
	pthread_exit(NULL);
	return NULL;
}

/*change "timerLen" type to uint32 for longer timeout, ZyXEL*/
int UIAddTimer(int id,uint32_t timerLen,TMRFUNC timefn,void *privdata)
{
	timer_list_iterator_t iter;
	CMTimer_t *uitimer,*intimer;
	int res=-1;

	uitimer = ZOS_MALLOC(sizeof(CMTimer_t));
	if (uitimer==NULL)
	{
		return res;
	}

//	gettimeofday(&uitimer->timeout, NULL);
	getSystemUptime(&uitimer->timeout);
	uitimer->TimerID = id;
	uitimer->TimerLen = timerLen;
#if 1  /* Solve inaccurate timer problem. Root cause: no consider that milisecond carry to second. Wayne fixed at 20090703. */
	uitimer->timeout.tv_usec  +=  timerLen*1000;
	uitimer->timeout.tv_sec  +=  uitimer->timeout.tv_usec/1000000;
	uitimer->timeout.tv_usec  =  uitimer->timeout.tv_usec%1000000;
#else
	uitimer->timeout.tv_sec  +=  timerLen/1000;
	uitimer->timeout.tv_usec  +=  (timerLen%1000)*1000;
#endif
	uitimer->data = (void*)privdata;
	uitimer->fn = timefn;

	pthread_mutex_lock(&timerMutex);
	intimer =(CMTimer_t*) timer_list_get_first( &time_list, &iter );
	pthread_mutex_unlock(&timerMutex);
	while(intimer){
		if(intimer->TimerID==id){
			intimer->TimerID=id;
			intimer->timeout.tv_sec=uitimer->timeout.tv_sec;
			intimer->timeout.tv_usec=uitimer->timeout.tv_usec;
			intimer->data= (void*)privdata;
			intimer->fn=timefn;

			return 0;
		}
		pthread_mutex_lock(&timerMutex);
		intimer=timer_list_get_next( &iter );
		pthread_mutex_unlock(&timerMutex);
	}
	pthread_mutex_lock(&timerMutex);
	res=timer_list_add(& time_list, uitimer, iter.pos )>0 ? 0: -1;
	pthread_mutex_unlock(&timerMutex);
	return res;
}

int UIAddPeriodicTimer(int id,int timerLen,TMRFUNC timefn,void *privdata)
{
	timer_list_iterator_t   iter;
	CMTimer_t               *uitimer,
	                        *intimer;
	int                     res=-1;

	uitimer = ZOS_MALLOC(sizeof(CMTimer_t));
	if (uitimer == NULL)
	{
		return res;
	}

	//gettimeofday(&uitimer->timeout, NULL);
	getSystemUptime(&uitimer->timeout);
	uitimer->TimerID = id;
	uitimer->TimerLen = timerLen;
	uitimer->timeout.tv_sec  +=  timerLen/1000;
	uitimer->timeout.tv_usec  +=  (timerLen%1000)*1000;
	uitimer->data = (void*)privdata;
	uitimer->fn = timefn;

	pthread_mutex_lock(&timerMutex);
	intimer =(CMTimer_t*) timer_list_get_first( &periodic_time_list, &iter );
	pthread_mutex_unlock(&timerMutex);
	while(intimer){
		if(intimer->TimerID==id){
			intimer->TimerID=id;
			intimer->timeout.tv_sec=uitimer->timeout.tv_sec;
			intimer->timeout.tv_usec=uitimer->timeout.tv_usec;
			intimer->data= (void*)privdata;
			intimer->fn=timefn;

			return 0;
		}
		pthread_mutex_lock(&timerMutex);
		intimer=timer_list_get_next( &iter );
		pthread_mutex_unlock(&timerMutex);
	}
	pthread_mutex_lock(&timerMutex);
	res=timer_list_add(& periodic_time_list, uitimer, iter.pos )>0 ? 0: -1;
	pthread_mutex_unlock(&timerMutex);
	return res;
}

int UIDelTimer(int id){
	CMTimer_t *uitimer=NULL;
	timer_list_iterator_t iter;
	int found = 0;

	pthread_mutex_lock(&timerMutex);
	uitimer =(CMTimer_t*) timer_list_get_first( &time_list, &iter );
	pthread_mutex_unlock(&timerMutex);
	while(uitimer){
		if(uitimer->TimerID !=id){
			pthread_mutex_lock(&timerMutex);
			uitimer =(CMTimer_t*) timer_list_get_next( &iter );
			pthread_mutex_unlock(&timerMutex);
			continue;
		}
		found = id;
		timer_list_iterator_remove(&iter);
		ZOS_FREE(uitimer);
		uitimer = NULL;
		memset(&iter,0,sizeof(timer_list_iterator_t));
		pthread_mutex_lock(&timerMutex);
		uitimer =(CMTimer_t*) timer_list_get_first( &time_list, &iter );
		pthread_mutex_unlock(&timerMutex);
	}

	return found;
}

int UIDelPeriodicTimer(int id){
	CMTimer_t *uitimer=NULL;
	timer_list_iterator_t iter;
	pthread_mutex_lock(&timerMutex);
	uitimer =(CMTimer_t*) timer_list_get_first( &periodic_time_list, &iter );
	pthread_mutex_unlock(&timerMutex);
	while(uitimer){
		if(uitimer->TimerID !=id){
			pthread_mutex_lock(&timerMutex);
			uitimer =(CMTimer_t*) timer_list_get_next( &iter );
			pthread_mutex_unlock(&timerMutex);
			continue;
		}
		timer_list_iterator_remove(&iter);
		ZOS_FREE(uitimer);
		uitimer = NULL;
		memset(&iter,0,sizeof(timer_list_iterator_t));
		pthread_mutex_lock(&timerMutex);
		uitimer =(CMTimer_t*) timer_list_get_first( &periodic_time_list, &iter );
		pthread_mutex_unlock(&timerMutex);
	}

	return 0;
}

int UIDelAllTimer(void){
	struct timer_list *list;

	pthread_mutex_lock(&timerMutex);
	list=&time_list;
	if(list->nb_elt>0){
		timer_list_special_free( &time_list, freeTime );
		timer_list_init( &time_list );
	}
	list=&periodic_time_list;
	if(list->nb_elt>0){
		timer_list_special_free( &periodic_time_list, freeTime );
		timer_list_init( &periodic_time_list );
	}
	pthread_mutex_unlock(&timerMutex);

	return 0;
}


void* freeTime( void* pData )
{
	CMTimer_t *uitimer = (CMTimer_t*)pData;

	if (uitimer)
	{
		ZOS_FREE( uitimer );
	}

	return NULL;
}

int getSystemUptime(struct timeval_t *timeout){
	FILE *uptimefd = NULL;
	char *currTime = NULL;
	char *pch = NULL;
	char buf[256]="";
	char strUptime[128]="";
	char uptime_sec[128]="";
	int i;
	char uptime_usec[128]="";
	char *tmp = NULL;

	uptimefd = fopen(UPTIME_FILE,"r");

	if(uptimefd != NULL){
		fgets(buf, 256, uptimefd);
		//currTime = strtok (buf," ");
		currTime = strtok_r(buf, " ", &tmp);
		if(currTime == NULL){
			printf("System internal error!\n");
			fclose(uptimefd);
			return 1;
		}

		sprintf(strUptime, "%s", currTime);
		strcat(strUptime, "0000");
		//printf("strUptime   : %s\n", strUptime);
		sprintf(uptime_sec, "%s", strUptime);

		for(i=0; i<=strlen(uptime_sec); i++){
			if(uptime_sec[i] == '.'){
				uptime_sec[i] = '\0';
				timeout->tv_sec = atoi(uptime_sec);
				//printf("time->sec   : %d\n", timeout->tv_sec);
				break;
			}
		}

		pch = strstr(strUptime, ".");
		pch = pch + 1;
		strcpy(uptime_usec, pch);

		timeout->tv_usec = atoi(uptime_usec);
		//printf("usec = %d\n", timeout->tv_usec);

		fclose(uptimefd);
		return 0;
	}

	return 1;
}

void zyTms_get(struct timespec *tms)
{
	struct timespec ts;
	int rc;

	if(tms == NULL){
		return;
	}

	rc = clock_gettime(CLOCK_MONOTONIC, &ts);
	if(rc == 0){
		tms->tv_sec = ts.tv_sec;
		tms->tv_nsec = ts.tv_nsec;
	}
	else{
		printf("clock_gettime failed, set timestamp to 0\n");
		tms->tv_sec = 0;
		tms->tv_nsec = 0;
	}
}
